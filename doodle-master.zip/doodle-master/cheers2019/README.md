Cheers, to Dockercon 2019!
==========================

Cheers, everybody!

It's time for Dockercon SF 2019, and Moby wanted to celebrate it in docker style!

To try it out, run:

`docker run -it --rm docker/doodle:cheers`

Complete source can be found [here](https://github.com/docker/doodle).
