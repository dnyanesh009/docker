A Docker Sixth Birthday Surprise
================================

Happy Birthday, Docker!

March 2019 marks Docker's sixth year, and we thought we'd celebrate it docker-style with a birthday surprise!
To try it out, run:

`docker run -it --rm docker/doodle:birthday`

Complete source can be found [here](https://github.com/docker/doodle).
